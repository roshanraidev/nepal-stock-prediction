
#Importing the require dependency
import pandas as pd
import numpy as np
import matplotlib.pylab as plt
from matplotlib.pylab import rcParams
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.arima_model import ARIMA
from pandas import DataFrame
import statsmodels.api as sm
import os


#Checking stationerity
from statsmodels.tsa.stattools import adfuller


class CompanyNABIL():
    def __init__(self):
        rcParams['figure.figsize'] = 15, 6


        #loading the datset
        self.dataset = pd.read_csv('NABIL.csv')
        initialList = DataFrame(self.dataset, columns = ['Date', 'Close'])
        self.dataset_list = initialList.values.tolist()
        
        self.dataset.head() #print the first 5 value from the dataset

        self.dataset.isnull().sum()

        # seting data as a index
        self.dataset.columns =['Date','Close']
        self.dataset = self.dataset.dropna()
        self.dataset['Date'] = pd.to_datetime(self.dataset['Date'])
        self.dataset.set_index('Date', inplace = True)

        #convert to time series:
        timeseries = self.dataset['Close']
        self.checking_stationerity(timeseries)

        
        #Making timeseries stationary by estimating and eliminating trend
        timeseries_log = np.log(timeseries)

        # smoothing moving average
        moving_avg = timeseries_log.rolling(12).mean()

        timeseries_log_moving_avg_diff = timeseries_log - moving_avg
        timeseries_log_moving_avg_diff.head(12)

        timeseries_log_moving_avg_diff.dropna(inplace=True)
        timeseries_log_moving_avg_diff.head()

        self.checking_stationerity(timeseries_log_moving_avg_diff)

        #Calculating exponentially weighted moving average
        exp_wighted_avg = timeseries_log.ewm(halflife=12,min_periods=0,adjust=True,ignore_na=False).mean()
        # plt.plot(timeseries_log)

        timeseries_log_ewma_diff = timeseries_log - exp_wighted_avg
        self.checking_stationerity(timeseries_log_ewma_diff)

        #Eliminating trend and seasonality 
        #Take first difference:
        timeseries_log_diff = timeseries_log - timeseries_log.shift()
        # plt.plot(timeseries_log_diff)
        # test_stationarity(ts_log_diff)

        timeseries_log_diff.dropna(inplace=True)
        self.checking_stationerity(timeseries_log_diff)

        #Decomposition
        decomposition = seasonal_decompose(timeseries_log)

        trend = decomposition.trend
        seasonal = decomposition.seasonal
        residual = decomposition.resid

        # plt.subplot(411)
        # plt.plot(timeseries_log, label='Original')
        # plt.legend(loc='best')
        # plt.subplot(412)
        # plt.plot(trend, label='Trend')
        # plt.legend(loc='best')
        # plt.subplot(413)
        # plt.plot(seasonal,label='Seasonality')
        # plt.legend(loc='best')
        # plt.subplot(414)
        # plt.plot(residual, label='Residuals')
        # plt.legend(loc='best')
        # plt.tight_layout()

        timeseries_log_decompose = residual
        timeseries_log_decompose.dropna(inplace=True)
        self.checking_stationerity(timeseries_log_decompose)


        # ACF and PACF plots:
        # from statsmodels.tsa.stattools import acf, pacf  
        # from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
        # acf = plot_acf(dataset.Close)

        # pacf = plot_pacf(dataset.Close)

        #MA model:
        model = ARIMA(timeseries_log, order=(2, 1, 0))  
        results_AR = model.fit(disp=-1)  
        # plt.plot(timeseries_log_diff)
        # plt.plot(results_AR.fittedvalues, color='red')
        # plt.title('RSS: %.4f'% sum((results_AR.fittedvalues-timeseries_log_diff)**2))

        model = ARIMA(timeseries_log, order=(0, 1, 1))  
        results_MA = model.fit(disp=-1)  
        # plt.plot(timeseries_log_diff)
        # plt.plot(results_MA.fittedvalues, color='red')
        # plt.title('RSS: %.4f'% sum((results_MA.fittedvalues-timeseries_log_diff)**2))

        from pmdarima.arima import auto_arima
        model_autoARIMA = auto_arima(self.dataset, start_p=0, start_q=0,
                            test='adf',       # use adftest to find             optimal 'd'
                            max_p=3, max_q=3, # maximum p and q
                            m=1,              # frequency of series
                            d=None,           # let model determine 'd'
                            seasonal=False,   # No Seasonality
                            start_P=0, 
                            D=0, 
                            trace=True,
                            error_action='ignore',  
                            suppress_warnings=True, 
                            stepwise=True)
        print(model_autoARIMA.summary())

        model=sm.tsa.statespace.SARIMAX(self.dataset['Close'],order=(0, 1, 0),seasonal_order=(2,1,0,12))
        fitted = model.fit(disp=-1)  
        print(fitted.summary())


        self.prediction_value= fitted.forecast(steps=30)
        
        self.predictedList = self.prediction_value.values.tolist()
    def showGraph(self):
        ax = self.dataset.plot(label='Past value', figsize=(16, 10))
        self.prediction_value.plot(ax=ax, label='Predicted')
        ax.set_xlabel('Date')
        ax.set_ylabel('close price')
        plt.legend()
        plt.show()

    
    def getDatasetList(self):
        return self.dataset_list
    
    def getPredictedList(self):
        return self.predictedList

    def getDate(self):
        datelist = []
        for i in range(1,31):
            datelist.append('2020-03-{}'.format(i))
            i += 1
        return datelist   


    def getComputedPredictedList(self):
        output = []
        dateList = self.getDate()
        i = 0
        for element in self.predictedList:
            output.append([dateList[i], element])
            i += 1

        return output

    def checking_stationerity(self, timeseries):
            
            rolling_mean = pd.Series(timeseries).rolling(window=12).mean()
            rolling_std = pd.Series(timeseries).rolling(window=12).std()
            
            #Perform Dickey-Fuller test:
            print ('Results of Dickey-Fuller Test:')
            dickey_fuller_test = adfuller(timeseries, autolag='AIC')
            dickey_fuller_output = pd.Series(dickey_fuller_test[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
            for key,value in dickey_fuller_test[4].items():
                dickey_fuller_output['Critical Value (%s)'%key] = value
            print (dickey_fuller_output)




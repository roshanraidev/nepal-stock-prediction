from flask import Flask, render_template, request, url_for, redirect
from Companies.Comp_ADBL import CompanyADBL
from Companies.Comp_AHPC import CompanyAHPC
from Companies.Comp_CHCL import CompanyCHCL
from Companies.Comp_NABIL import CompanyNABIL
from Companies.Comp_NBB import CompanyNBB

app = Flask(__name__, static_folder='static', template_folder='templates')

 
@app.route('/')
def get_homepage():
    return render_template('layout.html')

@app.route('/company-ADBL', methods = ['GET', 'POST'])
def get_companyADBL():
    compInstance = CompanyADBL()
    
    dataset = compInstance.getDatasetList()
    
    predictedList = compInstance.getComputedPredictedList()

    if request.method == 'POST':
        compInstance.showGraph()
    
    return render_template('company-ADBL.html', dataset = dataset, predictedList = predictedList)

@app.route('/company-AHPC', methods = ['GET', 'POST'])
def get_companyAHPC():
    compInstance = CompanyAHPC()
    
    dataset = compInstance.getDatasetList()
    
    predictedList = compInstance.getComputedPredictedList()

    if request.method == 'POST':
        compInstance.showGraph()
    
    return render_template('company-AHPC.html', dataset = dataset, predictedList = predictedList)

@app.route('/company-CHCL', methods = ['GET', 'POST'])
def get_companyCHCL():
    compInstance = CompanyCHCL()
    
    dataset = compInstance.getDatasetList()
    
    predictedList = compInstance.getComputedPredictedList()

    if request.method == 'POST':
        compInstance.showGraph()
    
    return render_template('company-CHCL.html', dataset = dataset, predictedList = predictedList)

@app.route('/company-NABIL', methods = ['GET', 'POST'])
def get_companyNABIL():
    compInstance = CompanyNABIL()
    
    dataset = compInstance.getDatasetList()
    
    predictedList = compInstance.getComputedPredictedList()

    if request.method == 'POST':
        compInstance.showGraph()
    
    return render_template('company-NABIL.html', dataset = dataset, predictedList = predictedList)

@app.route('/company-NBB', methods = ['GET', 'POST'])
def get_companyNBB():
    compInstance = CompanyNBB()
    
    dataset = compInstance.getDatasetList()
    
    predictedList = compInstance.getComputedPredictedList()

    if request.method == 'POST':
        compInstance.showGraph()
    
    return render_template('company-NBB.html', dataset = dataset, predictedList = predictedList)
if __name__ == "__main__":
    app.run(debug=True,port=8000)
    